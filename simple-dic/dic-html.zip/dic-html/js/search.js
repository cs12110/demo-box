function search() {
  var key = $("input[name=key]").val().trim();

  if(''==key){
  	return;
  }

  var word = cet4[key];

  if(undefined != word){
    showUp(word,key);
    return;
  }

  word = moreWords[key];
  showUp(word,key);
}
