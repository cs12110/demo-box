
/**
 *显示单词
 *
 */
function showUp(word,key){
  if (undefined == word) {
    $("#target-word").html("Oops,we can't find ["+key+"]");
    $("#spell-eng").hide();
    $("#spell-usa").hide();
    $("#word-meaning").hide();
    return;
  }

  $("#target-word").show();
  $("#spell-eng").show();
  $("#spell-usa").show();
  $("#word-meaning").show();

  var means = word.means;
  var len = means.length;

  var meansHtml = "";
  for (index = 0; index < len; index++) {
    meansHtml = meansHtml + means[index] + "<br/><br/>";
  }

  $("#target-word").html(word.word+"<br/><br/>");
  $("#spell-eng").html("英式:&nbsp;"+word.eng);
  $("#spell-usa").html("美式:&nbsp;"+word.usa);
  $("#word-meaning").html(meansHtml);
}
