var cet4Num = 0;
var cet4KeyArr = new Array();

var myClock;
var stopTime = 5000;

$(function() {
	for(var item in cet4) {
		cet4Num = cet4Num + 1;
		cet4KeyArr.push(item);
	}
	remember('cet4');
});

/**
 * 记忆等级
 * @param {Object} level
 */
function remember(level) {
	if(level == 'cet4') {
		nextCet4();
	}
}

/**
 * 是否自动显示
 * 
 * @param {Object} thisObj
 */
function powerBtn(thisObj) {
	var str = $(thisObj).text();
	if('[Stop]' == str) {
		clearInterval(myClock);
		$(thisObj).text('[Auto]');
	} else {
		randomNextCet4();
		$(thisObj).text('[Stop]');
	}
}

function nextCet4() {
	clearInterval(myClock);
	$("#power-btn").text('[Auto]');
	var rIndex = Math.round(Math.random() * cet4Num);
	var word = cet4[cet4KeyArr[rIndex]];
	showUp(word, '');
}

/**
 * 显示下一个四级词汇
 */
function randomNextCet4() {
	var rIndex = Math.round(Math.random() * cet4Num);
	var word = cet4[cet4KeyArr[rIndex]];
	showUp(word, '');

	clearInterval(myClock);
	myClock = setInterval('randomNextCet4()', stopTime);

}