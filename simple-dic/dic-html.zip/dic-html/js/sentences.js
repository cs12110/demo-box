var limit = 5;
var len = sentenceArr.length;
var watchSeconds = 10;

var sentenceClock;

$(function() {
	randomShowUp();
});

/**
 * 检索句子
 */
function search() {
	var key = $("input[name=key]").val().trim();

	if('' == key) {
		randomShowUp();
		return;
	}

	clearInterval(sentenceClock);
	var num = 0;
	var regex = new RegExp(key, "i");
	var html = "";
	for(var index = 0; index < len; index++) {
		if(num >= limit) {
			break;
		}
		var tmp = sentenceArr[index];
		if(regex.test(tmp.sentence) || regex.test(tmp.means)) {
			num = num + 1;
			html += buildSentenceArea(tmp);
		}
	}
	showSentence(html);
}

/**
 * 随机显示句子
 */
function randomShowUp() {
	var sentence = sentenceArr[randomIndex()];
	var html = buildSentenceArea(sentence);
	showSentence(html);
	if(undefined != sentenceClock) {
		clearInterval(sentenceClock);
	}
	sentenceClock = setInterval("randomShowUp()", watchSeconds * 1000);
}

/**
 * 显示句子
 * @param {Object} sentence
 */
function showSentence(html) {
	$("#sentence-html").html(html);
}

/**
 * 获取随机数
 */
function randomIndex() {
	return Math.round(Math.random() * len);
}

/**
 * 创建显示区域
 * @param {Object} sentence
 */
function buildSentenceArea(sentence) {
	var html = "<div class='sentence-body'>";
	html += "<div class='en-sentence'>" + sentence.sentence + "</div>";
	html += "<div class='zh-sentence'>" + sentence.means + "</div>";
	html += "</div>";
	return html;
}